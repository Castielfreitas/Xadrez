-- Sandbox MVP: one aggregate, optimistic concurrency. No real-money deposits.
create table if not exists public.arena_state (
 id text primary key check (id = 'main'),
 state jsonb not null,
 revision bigint not null default 0,
 updated_at timestamptz not null default now()
);
alter table public.arena_state enable row level security;
revoke all on public.arena_state from public, anon, authenticated;
grant select,update,insert on public.arena_state to service_role;
create or replace function public.arena_compare_and_swap(expected_revision bigint,next_state jsonb)
returns boolean language plpgsql security invoker set search_path = '' as $$
begin
 update public.arena_state set state=next_state,revision=revision+1,updated_at=now() where id='main' and revision=expected_revision;
 return found;
end;$$;
revoke all on function public.arena_compare_and_swap(bigint,jsonb) from public,anon,authenticated;
grant execute on function public.arena_compare_and_swap(bigint,jsonb) to service_role;
insert into public.arena_state(id,state) values ('main','{"version":1,"settings":{"feeBps":1000,"analysisEnabled":false,"mode":"sandbox"},"players":{},"challenges":[],"games":[],"tournaments":[],"ledger":[],"reviews":[],"audit":[],"commands":[]}'::jsonb) on conflict do nothing;
