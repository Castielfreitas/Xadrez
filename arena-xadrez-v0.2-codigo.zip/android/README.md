# Android — Arena Xadrez

Projeto Android nativo que carrega apenas a origem HTTPS configurada em `app/build.gradle`. Sem permissão de câmera, microfone, arquivos ou instalação de pacotes. `FLAG_SECURE` limita capturas e gravação de tela no aparelho, mas não bloqueia câmera externa e não oferece proteção infalível.

## Gerar o aplicativo

Requer Android Studio, JDK 17+, SDK Android API 36 e Gradle 8.13. Abra esta pasta no Android Studio, sincronize o Gradle e use **Build > Generate Signed App Bundle / APK**. Crie a assinatura na sua máquina, sem enviar a chave privada para o GitHub. Para testes locais, `gradle :app:assembleDebug`; para o pacote da loja, configure a assinatura e execute `gradle :app:bundleRelease`.

Esta entrega contém o código-fonte. Não contém APK/AAB compilado nem assinado. Antes da distribuição, faça testes em dispositivos, acessibilidade, conexão instável, retorno de login e alterações de orientação.

A política Google Play sobre jogos/torneios com dinheiro real não autoriza automaticamente o modelo proposto. Esta versão usa créditos fictícios, sem compra, saque, conversão ou links para apostas reais. Não habilitar dinheiro real remotamente para contornar a revisão da loja. Conta Play Console, ficha de segurança de dados, política de privacidade pública, classificação indicativa e testes exigidos devem ser concluídos antes da submissão.
