package br.com.arenaxadrez.app;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.graphics.Color;
public final class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
  web=new WebView(this); web.setBackgroundColor(Color.rgb(18,23,22));
  WebSettings settings=web.getSettings();
  settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
  settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
    Uri uri=request.getUrl();Uri origin=Uri.parse(BuildConfig.ARENA_URL);
    if("https".equals(uri.getScheme()) && origin.getHost().equals(uri.getHost()) && uri.getPort()==origin.getPort())return false;
    if(request.isForMainFrame() && "https".equals(uri.getScheme())) {
     try {startActivity(new Intent(Intent.ACTION_VIEW,uri));} catch(Exception ignored) {}
    }
    return true;
   }
  });
  setContentView(web); if(savedInstanceState==null)web.loadUrl(BuildConfig.ARENA_URL);else web.restoreState(savedInstanceState);
 }
 @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);web.saveState(state);}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
